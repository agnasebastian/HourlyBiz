import 'package:flutter/material.dart';
import 'Widgets/userdefinedwidget.dart';
import 'onboardscreen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateHome();
  }

  _navigateHome() async {
    await Future.delayed(const Duration(milliseconds: 4000), () async {
      await Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => const OnboardScreen()));
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/images/HourlyBiz.png',
                width: 200.0, height: 200.0, fit: BoxFit.cover
            ),
            SizedBox(
                height: 40,
                width: 60,
                child: splashScreenLoading()
            ),
          ],
        ),
      ),
    );
  }
}



