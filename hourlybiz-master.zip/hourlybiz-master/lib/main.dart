import 'package:flutter/material.dart';
import 'package:hourlybiz/appcolors.dart';
import 'package:hourlybiz/loginscreen.dart';
import 'package:hourlybiz/splashscreen.dart';
import 'package:hourlybiz/usersignup.dart';

void main() async{
  runApp(
    const MyApp(),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        scaffoldBackgroundColor: ColorConstants.MilkCoffee,
      ),
      home: const SplashScreen(),
    );
  }
}