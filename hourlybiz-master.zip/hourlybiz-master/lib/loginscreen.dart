import 'package:flutter/material.dart';
import 'package:hourlybiz/appcolors.dart';
import 'package:hourlybiz/usersignup.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      title: "HourlyBiz",
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Sign In'),
          centerTitle: true,
          backgroundColor: ColorConstants.DarkCoffee,
        ),
        backgroundColor: ColorConstants.MilkCoffee,
        body: const MyStatefulWidget(),
      ),
    );
  }
}

class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key}) : super(key: key);

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(10),
        child: ListView(
          children: <Widget>[
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(10),
              child: Image.asset('assets/images/HourlyBiz.png',
                  width: 125.0, height: 125.0, fit: BoxFit.cover),
            ),
            Container(
              padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 50.0),
              child: TextField(
                controller: nameController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  labelText: 'eMail/Mobile No',
                ),
              ),
            ),
            TextButton(
              onPressed: () {},
              child: const Text(
                'Forgot Password',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
            ),
            Container(
                height: 50,
                padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                child: ElevatedButton(
                  onPressed: () {
                    //print(nameController.text);
                    //print(passwordController.text);
                  },
                  style: ElevatedButton.styleFrom(
                    primary: ColorConstants.DarkCoffee,
                    shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(15.0)), // Background color
                  ),
                  child: const Text(
                    'Sign In',
                    style: TextStyle(fontSize: 20),
                  ),
                )),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Text(
                  'Do not have an account?',
                  style: TextStyle(fontSize: 17),
                ),
                TextButton(
                  child: const Text(
                    'Sign Up',
                    style: TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const UserSignUp()));
                  },
                )
              ],
            ),
          ],
        ));
  }
}
