import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:loading_indicator/loading_indicator.dart';

Widget splashScreenLoading() {
  const List<Color> _listColors = [
    Colors.red,
    Colors.pinkAccent,
    Colors.redAccent,
    Colors.deepOrange,
    Colors.orange,
  ];
  return const LoadingIndicator(
    indicatorType: Indicator.lineScale,
    colors: _listColors,
  );
}