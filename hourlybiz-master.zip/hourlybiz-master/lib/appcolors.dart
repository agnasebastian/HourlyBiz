import 'dart:ui';

class ColorConstants {
  static const RoseWater = Color(0xFFE8B4B8);
  static const DustyRose = Color(0xFFEED6D3);
  static const CoffeePotLight = Color(0xFFA49393);
  static const CoffeePotDark = Color(0xFF67595E);
  static const DarkCoffee = Color(0xFF3c2f2f);
  static const MediumCoffee = Color(0xFF6f4436);
  static const LightCoffee = Color(0xFF854442);
  static const CaramelCoffee = Color(0xFFbe9b7b);
  static const MilkCoffee = Color(0xFFe2d1c5);
  //static const MilkCoffee = Color(0xFFdfccaf);
  static const WhiteCoffee = Color(0xFFFFFFFF);
}